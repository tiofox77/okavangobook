<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['field' => null, 'sortField' => null, 'sortDirection' => 'asc']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['field' => null, 'sortField' => null, 'sortDirection' => 'asc']); ?>
<?php foreach (array_filter((['field' => null, 'sortField' => null, 'sortDirection' => 'asc']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<!--[if BLOCK]><![endif]--><?php if($sortField !== $field): ?>
    <i class="fas fa-sort text-gray-400 ml-1"></i>
<?php elseif($sortDirection === 'asc'): ?>
    <i class="fas fa-sort-up text-indigo-600 dark:text-indigo-400 ml-1"></i>
<?php else: ?>
    <i class="fas fa-sort-down text-indigo-600 dark:text-indigo-400 ml-1"></i>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php /**PATH C:\laragon\www\okavangobook\resources\views/components/admin/sort-icon.blade.php ENDPATH**/ ?>